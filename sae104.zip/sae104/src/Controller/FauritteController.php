<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class FauritteController extends AbstractController
{
    #[Route('/viallon', name: 'app_viallon')]
    public function index(): Response
    {
        return $this->render('fauritte/index.html.twig', [
            'controller_name' => 'FauritteController',
        ]);
    }
    #[Route('/viallon2', name: 'app_viallon2')]
    public function index2(): Response
    {
        return $this->render('viallon/index2.html.twig', [
            'controller_name' => 'FauritteController',
        ]);
    }
}
